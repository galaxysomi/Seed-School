const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const lop = new Schema({
    Ten: {
        type: String,
        required: true
    },
    Siso: {
        type: Number,
        required: true
    },
    GV: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true,
        ref: "giaovien"
    }
}, {
    collection: "Lớp"
})

module.exports = mongoose.model("lop",lop);

