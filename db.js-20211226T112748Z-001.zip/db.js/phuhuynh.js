const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const phuhuynh = new Schema({
    Ten: {
        type: String,
        required: true
    },
    Ngaysinh: {
        type: Date,
        required: true
    },
    Gioitinh: {
        type: String,
        enum: ["Nam","Nữ"],
        required: true
    },
    SoDT: {
        type: String,
        required: true
    },
    Diachi: {
        type: String,
        required: true
    },
    HS: {
        type: [mongoose.SchemaTypes.ObjectId],
        required: true,
        ref: "hocsinh"
    }
}, {
    collection: "Phụ huynh"
})

module.exports = mongoose.model("phuhuynh",phuhuynh);

