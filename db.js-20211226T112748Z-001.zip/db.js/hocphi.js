const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const hocphi = new Schema({
    HS: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true,
        ref: "hocsinh"
    },
    Thang: {
        type: Number,
        required: true
    },
    Hocphi: {
        type: Schema.Types.Decimal128,
        required: true
    }
}, {
    collection: "Học phí"
})

module.exports = mongoose.model("hocphi",hocphi);

