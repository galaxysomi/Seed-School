const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const thucdon = new Schema({
    Ngay: {
        type: Date,
        required: true
    },
    Buoi: {
        type: String,
        enum: ["Bữa sáng","Bữa trưa","Bữa xế chiều"],
        required: true
    },
    Menu: {
        type: [String],
        required: true
    }  
}, {
    collection: "Menu thực đơn"
})

module.exports = mongoose.model("thucdon",thucdon);
