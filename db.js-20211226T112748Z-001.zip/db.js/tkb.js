const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const tkb = new Schema({
    Lop: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true,
        ref: "lop"
    },
    Ngay: {
        type: Date,
        required: true
    },
    Cachd: { 
        type: [String], 
        required: true
    }
}, {
    collection: "Thời khóa biểu"
})

module.exports = mongoose.model("tkb",tkb);

