const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const hopthuph = new Schema({
    PH: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true,
        ref: "phuhuynh"
    },
    Ngay: {
        type: Date,
        required: true
    },
    Noidung: {
        type: String,
        required: true
    }    
}, {
    collection: "Hộp thư phụ huynh"
}) 
module.exports = mongoose.model("hopthuph",hopthuph);

