const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const sotheodoi = new Schema({
    HS: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true,
        ref: "hocsinh"
    },
    Ngay: {
        type: Date,
        required: true
    },
    Anhdiemdanh: {
        type: String,   
        required: true        
    },
    TKB: {
        type: [String],
        required: true
    },
    Nhanxet: {
        type: String, 
    },
    Trongmuon: {
        Sau18h30: {
            type: Number, 
            enum: [0,1],
            required: true   
        },
        Tu17h30den18h30: {
            type: Number,
            enum: [0,1],
            required: true
        },
        Dunggio: {
            type: Number,
            enum: [0,1],
            required: true
        } 
    },
    Dimuon: {
        type: Number,
        enum: [0,1],   
        required: true
    }
}, {
    collection: "Sổ theo dõi"
})

module.exports = mongoose.model("sotheodoi",sotheodoi);

