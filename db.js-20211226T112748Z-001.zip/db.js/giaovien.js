const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const giaovien = new Schema({
    Ten: {
        type: String,
        required: true
    },
    Ngaysinh: {
        type: Date,
        required: true
    },
    Gioitinh: {
        type: String,
        enum: ["Nam","Nữ"],
        required: true
    },
    SoDT: {
        type: String,
        required: true
    },
    Lop: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true,
        ref: "lop"
    },
}, {
    collection: "Giáo viên"
})

module.exports = mongoose.model("giaovien",giaovien);

