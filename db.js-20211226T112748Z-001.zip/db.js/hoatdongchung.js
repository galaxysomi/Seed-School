const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const hdchung = new Schema({
    Thoigian: { 
        type: Date, 
        required: true
    },
    Noidung: {
        type: String,
        required: true
    },
    Ghichu: {
        type: String,
        required: true
    }
}, {
    collection: "Hoạt động chung"
})

module.exports = mongoose.model("hdchung",hdchung);

