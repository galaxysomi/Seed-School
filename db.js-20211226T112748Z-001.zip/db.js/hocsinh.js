const mongoose = require("mongoose");   

const Schema = mongoose.Schema;

const hocsinh = new Schema({   
    Ten: {
        type: String,
        required: true   
    },
    Ngaysinh: {
        type: Date,
        required: true
    },
    Gioitinh: {
        type: String,
        enum: ["Nam","Nữ"],   
        required: true
    },
    Lop: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true,
        ref: "lop"   
    },
    PH: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true,
        ref: "phuhuynh"
    }
}, {
    collection: "Student"   
})

module.exports = mongoose.model("student",student)  
