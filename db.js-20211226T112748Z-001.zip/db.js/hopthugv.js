const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const hopthugv = new Schema({
    GV: {
        type: mongoose.SchemaTypes.ObjectId,
        required: true,
        ref: "giaovien"
    },
    Ngay: {
        type: Date,
        required: true
    },
    Ykienph: {
        type: String
    },
    Donnghihoc: {
        type: String
    }
}, {
    collection: "Hộp thư giáo viên"
})

module.exports = mongoose.model("hopthugv",hopthugv)
